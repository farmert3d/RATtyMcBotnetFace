import socket
import os
import time
import sys
import subprocess

timeout = time.time() + 1   # 1 seconds from now
while time.time() <= timeout:
    cmd = "ping 127.0.0.1"
    #os.system(cmd)
    #subprocess.check_output(cmd, shell=True)
    proc = subprocess.Popen('cmd.exe', stdin = subprocess.PIPE, stdout = subprocess.PIPE)
    stdout, stderr = proc.communicate(cmd)
    stdout
