#server.py
import socket
import sys
import os
from thread import start_new_thread

picture ="""
-------------------------------------------------------------------------------



       _______   _    _   _            _    _           __   __   _
      |__   __| | | |  \/  |  ______  |  \/  |     /\   \ \_/ /  | |
         | |    | | | \  / | |______| | |\/| |    /  \   \   /   | |
         | |    | | | |\/| |          | |  | |   / /\ \   | |    | |
         | |    | | | |  | |          | |  | |  / /__\ \  | |    |_|
         |_|    | | |_|  |_|          |_|  |_| /_/    \_\ |_|    (_)




-------------------------------------------------------------------------------
"""
print picture
#--------------------Setting up the server------------------#
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)          # Create a socket object
host = ""                                                      # Setting host to anything
port = 9999                                                    # Reserve a port for your service.
s.bind((host, port))                                           # Bind to the port
s.listen(5)                                                    # Now wait for client connection.
print "Server listening...."

#------Setting up threading and recieving/sending data------#
def client_thread(conn):
    conn.send("Welcome to the Server.")
    while True:
        data = conn.recv(1024)
        print data
        if not data:
            break

while True:
    #have this run for a set time then automatically go to the cmd section
    conn, addr = s.accept()
    print("[-] Connected to " + addr[0] + ":" + str(addr[1]))
    start_new_thread(client_thread, (conn,))

    print ">>> "
    cmd = raw_input("")
    if (cmd == "quit" or cmd == "exit" or cmd == "close"):
        conn.send(cmd)
        os._exit(1)
    else:
        conn.send(cmd)
